/*
 * user_ir.h
 *
 *  Created on: 2017��7��10��
 *      Author: Administrator
 */

#ifndef _USER_IR_H_
#define _USER_IR_H_

extern void user_ir_test_func(void);

#endif /* _USER_IR_H_ */

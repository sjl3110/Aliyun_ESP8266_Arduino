/*
 * user_sntp.h
 *
 *  Created on: 2017��7��7��
 *      Author: Administrator
 */

#ifndef _USER_SNTP_H_
#define _USER_SNTP_H_

extern void user_sntp_init(void);

#endif /* _USER_SNTP_H_ */

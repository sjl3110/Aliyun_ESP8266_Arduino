/*
 * user_gpio.h
 */

#ifndef _USER_GPIO_H_
#define _USER_GPIO_H_

extern void user_gpio_interrupt_init(void);
extern void user_gpio_timer_init(void);

#endif /* _USER_GPIO_H_ */

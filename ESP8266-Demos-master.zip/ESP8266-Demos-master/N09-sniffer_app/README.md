# sniffer_app

ESP8266使用sniffer获取周围设备的MAC地址。

效果图

![ESP826-sniffer-demo](screenshot/sniffer.jpg)

相关博客：http://blog.csdn.net/yannanxiu/article/details/72778688

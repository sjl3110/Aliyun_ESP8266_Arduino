/*
 * tcp_client.h
 *
 *  Created on: 2017��7��3��
 *      Author: Administrator
 */

#ifndef _TCP_CLIENT_H_
#define _TCP_CLIENT_H_

#include "ets_sys.h"
#include "os_type.h"

extern void tcp_client_init(u8* ip, u16 port);

#endif /* _TCP_CLIENT_H_ */

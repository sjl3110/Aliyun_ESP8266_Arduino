/*
 * user_adc.h
 *
 *  Created on: 2017��7��5��
 *      Author: Administrator
 */

#ifndef _USER_ADC_H_
#define _USER_ADC_H_

extern void adc_timer_init(void);

#endif /* _USER_ADC_H_ */

/*
 * user_wifi.h
 *
 *  Created on: 2017��7��4��
 *      Author: Administrator
 */

#ifndef _USER_WIFI_H_
#define _USER_WIFI_H_

extern void user_set_station_config(u8* ssid, u8* password);
extern void user_wifi_init(void);

#endif /* _USER_WIFI_H_ */

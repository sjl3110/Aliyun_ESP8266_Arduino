/*
 * smart_config.h
 */

#ifndef _USER_SMARTCONFIG_H_
#define _USER_SMARTCONFIG_H_

#include "ets_sys.h"
#include "osapi.h"
#include "ip_addr.h"
#include "espconn.h"
#include "mem.h"

#include "smartconfig.h"

extern void smartconfig_done(sc_status status, void *pdata);

#endif /* _USER_SMARTCONFIG_H_ */

/*
 * user_iic.h
 *
 *  Created on: 2017��7��21��
 *      Author: Administrator
 */

#ifndef _USER_IIC_H_
#define _USER_IIC_H_

#include "ets_sys.h"
#include "osapi.h"
#include "user_interface.h"

#include "driver/i2c_master.h"

#endif /* _USER_IIC_H_ */

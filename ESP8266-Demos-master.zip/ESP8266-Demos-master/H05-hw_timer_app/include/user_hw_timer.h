/*
 * user_hw_timer.h
 *
 *  Created on: 2018年3月13日
 *      Author: Administrator
 */

#ifndef _USER_HW_TIMER_H_
#define _USER_HW_TIMER_H_

extern void user_hw_timer_init(void);
extern void user_hw_timer_delete(void);

#endif /* _USER_HW_TIMER_H_ */

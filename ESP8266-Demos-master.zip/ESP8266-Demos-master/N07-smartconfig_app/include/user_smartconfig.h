/*
 * smart_config.h
 *
 *  Created on: 2017��7��3��
 *      Author: Administrator
 */

#ifndef _USER_SMART_CONFIG_H_
#define _USER_SMART_CONFIG_H_

#include "user_interface.h"
#include "smartconfig.h"
#include "airkiss.h"

extern void smartconfig_done(sc_status status, void *pdata);
extern void user_smartconfig_init(void);

#endif /* _USER_SMART_CONFIG_H_ */

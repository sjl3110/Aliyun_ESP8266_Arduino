/*
 * udp_server.h
 *
 *  Created on: 2017��7��3��
 *      Author: Administrator
 */

#ifndef _UDP_SERVER_H_
#define _UDP_SERVER_H_

#include "c_types.h"

/* UDP Server ��ʼ�� */
extern void udp_server_init(u32 port);
extern void multiudp_init(void);

#endif /* _UDP_SERVER_H_ */

/*
 * base64.h
 *
 *  Created on: 2017��8��28��
 *      Author: Administrator
 */

#ifndef _BASE64_H_
#define _BASE64_H_

#include "ets_sys.h"
#include "osapi.h"
#include "user_interface.h"

extern int base64_encode(const u8 inputdata[], u8 outputdata[]);

#endif /* _BASE64_H_ */

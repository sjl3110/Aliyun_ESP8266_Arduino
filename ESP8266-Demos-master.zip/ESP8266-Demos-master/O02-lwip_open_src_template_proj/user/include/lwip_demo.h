/*
 * lwip_demo.h
 *
 *  Created on: 2018��1��3��
 *      Author: Administrator
 */

#ifndef _LWIP_DEMO_H_
#define _LWIP_DEMO_H_

extern void udp_demo_init(void);
extern void tcpserver_init(void);

#endif /* _LWIP_DEMO_H_ */
